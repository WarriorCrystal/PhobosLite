package me.earth.phobos.features.modules.render;

import me.earth.phobos.event.events.Render3DEvent;
import me.earth.phobos.features.modules.Module;
import me.earth.phobos.features.modules.combat.AutoCrystal;
import me.earth.phobos.features.setting.Setting;
import net.minecraft.entity.player.EntityPlayer;

import java.util.*;

public class PopChams extends Module {

    public static PopChams INSTANCE;

    public PopChams() {
            super("PopChams", "shows ez logs", Module.Category.RENDER, false, false, false);
            this.setInstance();
    }

    public Setting<Mode> mode = this.register(new Setting<Object>("Mode", Mode.WIRE));
    public Setting<Float> width = register(new Setting<Object>("Width", 2.0f, 0.0f, 5.0f, v -> mode.getValue() == Mode.WIRE));
    public Setting<Boolean> texture = this.register(new Setting<Object>("Texture", false));
    public Setting<Boolean> lighting = register(new Setting<Object>("Lighting", false));
    public Setting<Boolean> blend = register(new Setting<Object>("Blend", false));
    public Setting<Boolean> transparent = register(new Setting<Object>("Transparent", false));
    public Setting<Boolean> depth = register(new Setting<Object>("Depth", false));
    public Setting<Boolean> xqz = register(new Setting<Object>("XQZ", false));
    public Setting<Integer> yTravel = register(new Setting<>("Y Travel", 0, -10, 10));
    public Setting<Integer> aliveTicks = register(new Setting<>("Alive Ticks", 20, 0, 100));

    public HashMap<EntityPlayer, Integer> poppedPlayers = new HashMap<>();

    @Override
    public void onRender3D(Render3DEvent event) {
        List<EntityPlayer> playersToRemove = new ArrayList<>();
        for (Map.Entry<EntityPlayer, Integer> player : poppedPlayers.entrySet()) {
            if (player.getValue() > aliveTicks.getValue()) {
                playersToRemove.add(player.getKey());
            }
            player.getKey().posY += yTravel.getValue();
            mc.renderManager.renderEntityStatic(player.getKey(), event.getPartialTicks(), false);
            player.setValue(player.getValue() + 1);
        }
        for (EntityPlayer player : playersToRemove) {
            poppedPlayers.remove(player);
        }
    }
    public static PopChams getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new PopChams();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }

    public enum Mode {
        MODEL,
        WIRE,
        SHINE,
        WIREMODEL,
    }
}